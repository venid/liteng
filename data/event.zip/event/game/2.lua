
return function (triger)
        if triger == 1
	        then Messages(0x00000051, 0);
        end
       end
