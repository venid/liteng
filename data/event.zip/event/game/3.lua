return function (triger)
        if triger == 1
        then foo();
        end
       end
