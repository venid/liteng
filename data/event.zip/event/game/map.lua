return function (triger)
        if triger == 1
        then if GameMode == 2
             then Messages(0x00000006, 1);
                  GameMode = 1;
             else Messages(0x00000006, 2);
                  GameMode = 2;
             end
        end
       end
