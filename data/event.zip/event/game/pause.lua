return function (triger)
        if triger == 1
        then if GameMode == 0
             then Messages(0x00000006, 1);
                  GameMode = 1;
             else Messages(0x00000006, 0);
                  GameMode = 0;
             end
        end
       end
