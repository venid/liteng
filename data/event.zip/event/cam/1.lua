return function (triger)
--        if triger == 1
--        then camera:dirDist(0.01);
--        else camera:dirDist(-0.01);
--        end
       end

