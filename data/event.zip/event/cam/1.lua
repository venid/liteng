return function (triger)
        if triger == 1
        then tp = camera.types;
             if tp == 1
             then camera.types = 2;
             else camera.types = 1;
             end
        end
       end

