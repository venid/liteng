return function (button, triger, x, y)
        camera:setFlag(triger);
        camera:setCursor(x, y); 
       end
