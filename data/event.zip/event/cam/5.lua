return function (flag)
        delta = camera.distance;
        delta = delta + (0.2 * flag);
        camera.distance = delta;
       end
