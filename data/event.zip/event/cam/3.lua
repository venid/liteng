return function (x, y)
        camera:rotation(x, y);
       end
